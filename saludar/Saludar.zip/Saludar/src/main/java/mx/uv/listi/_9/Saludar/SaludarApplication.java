package mx.uv.listi._9.Saludar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludarApplication.class, args);
	}

}
