package mx.uv.listi._9.Saludar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludarApplicationTests {

	@Test
	void contextLoads() {
	}

}
